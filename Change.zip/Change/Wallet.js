﻿app.controller("WalletController", function ($scope, $http, $filter) {
    $scope.model = {};
    $scope.showDetails = false;
    $scope.detailsFound = false;
    $scope.model.PaymentType = "Transfer";
    $scope.VehicleRespMsg="";    

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }





    $scope.CheckCustomer = function () {


        if ($scope.model.VehicleRegNo == "" || $scope.model.VehicleRegNo == null || $scope.model.VehicleRegNo == undefined) {
            WarnMessage("Please enter Vehicle Registration Number");
            return false;

        }
        else {
            $scope.ShowLoaderImg();
            $scope.VehicleParams = {};
            $scope.VehicleParams.vrn = $scope.model.VehicleRegNo;
            $http({
                method: 'POST',
                url: baseUrl + 'WalletRecharge/CheckFastagBalance',
                data: $scope.VehicleParams,
            }).then(function (response) {
                
                $scope.HideLoaderImg();

                $scope.showDetails = true;
                var result = [];

                $scope.details = [];

                if (response.data.Result.data.length > 0) {
                    for (var i = 0; i < response.data.Result.data.length; i++) {

                        result.push({ CustomerName: response.data.Result.data[i].customerName, MasterBalance: response.data.Result.data[i].masterBalance, MobileNum: response.data.Result.data[i].mobileNum, WalletBalance: response.data.Result.data[i].walletBalance, VRN: response.data.Result.data[i].vrn });
                        $scope.detailsFound = true;
                    }

                }
                else {
                      if(response.data.Result!=null)
                    {
                      $scope.VehicleRespMsg=response.data.Result.respMessage;
                   }
                }
                $scope.details = result;
                
                $scope.HideLoaderImg();





            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });
        }


    }



    $scope.CheckBalance = function (e) {
        if ($scope.model.FromAccountNumber == "" || $scope.model.FromAccountNumber == null || $scope.model.FromAccountNumber == undefined) {
            WarnMessage("Please enter From Account Number");
            return false;

        }
        else {
            $scope.ShowLoaderImg();
            $http({
                method: 'POST',
                url: baseUrl + 'Fastag/CheckAccountBalance?Id=' + $scope.model.FromAccountNumber,

            }).then(function (response) {
                
                $scope.HideLoaderImg();
                alert(response.data);

            }, function errorCallback(response) {
                $scope.HideLoaderImg();


            });
        }
    }


    $scope.Recharge = function () {
        if ($scope.validator.validate()) {
            $scope.ShowLoaderImg();

            $scope.WalletRecharge = {};
            $scope.WalletRecharge.Id = $scope.model.Id;
            $scope.WalletRecharge.VehicleRegNo = $scope.model.VehicleRegNo;
            $scope.WalletRecharge.Amount = $scope.model.Amount;
            $scope.WalletRecharge.FromAccountNumber = $scope.model.FromAccountNumber;
            $scope.WalletRecharge.ToAccountNumber = $scope.model.ToAccountNumber;
            $scope.WalletRecharge.PaymentType = $scope.model.PaymentType;
            $http({
                method: 'POST',
                url: baseUrl + 'WalletRecharge/RechargeWallet',
                data: $scope.WalletRecharge,
            }).then(function (response) {

                
                $scope.HideLoaderImg();


                if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "invalidaccount") {
                        SetMessage('InvalidAccount')
                    }
                }

                if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "exception") {
                        SetMessage('Error')
                    }
                }

                else if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "actDoesntExistOrBalanced") {
                        SetMessage('ActDoesntExistOrBalaned')
                    }
                }

                else if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "insuffiecient") {
                        SetMessage('Insufficient')
                    }
                }
                else if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "exceptionBal") {
                        SetMessage('BalException')
                    }
                }
                else if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "exceptionTrans") {
                        SetMessage('TransException')
                    }
                }

                else if (response.data.split('-')[0] == "success") {

                    alert(response.data.split('-')[1]);

                }
                else if (response.data.split('-')[0] == "failureRecharge") {
                    alert(response.data.split('-')[1]);
                }
               





            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });

        }
        }
    







    $scope.Registration = function (e) {
        window.location = "/Fastag/Registration";
    }
    $scope.Edit = function (e) {

        var Id = e.dataItem.Id;
        window.location = "/Fastag/Edit?Id=" + Id;
    }





});