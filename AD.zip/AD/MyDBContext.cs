﻿using MySql.Data.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.DAL
{

    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class MyDBContext : DbContext
    {

     
        public DbSet<Group> Group { get; set; }
        public DbSet<GroupDetail> GroupDetail { get; set; }
        public DbSet<Employee> Employee { get; set; }
        public DbSet<Branch> Branch { get; set; }
        public DbSet<Message> Message { get; set; }

        public DbSet<MessageDetail> MessageDetail { get; set; }
        public DbSet<MessageReplyDetail> MessageReplyDetail { get; set; }

        public DbSet<TestEmployee> TestEmployee { get; set; }
        public DbSet<TestBranch> TestBranch { get; set; }

        public MyDBContext()
      : base()
    {

        }

        // Constructor to use on a DbConnection that is already opened
        public MyDBContext(DbConnection existingConnection, bool contextOwnsConnection)
      : base(existingConnection, contextOwnsConnection)
    {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
           // modelBuilder.Entity<Car>().MapToStoredProcedures();
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }

   public class Group
    {
     
        public int Id { get; set; }
        public string Name { get; set; }       
        public string description { get; set; }
        public bool isdeleted { get; set; }
         public string createdby { get; set; }
        public DateTime createddate { get; set; }
    }

    public class GroupDetail
    {

        public int Id { get; set; }
        public int group_id { get; set; }
        public int branch_id { get; set; }      
        public bool isdeleted { get; set; }
        public string createdby { get; set; }
        public DateTime createddate { get; set; }
    }


    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string code { get; set; }
        public int branch_id { get; set; }
        public string samaccountname { get; set; }

    }

        public class Branch
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string code { get; set; }
          

        }


        public class Message
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int? group_id { get; set; }      
        public int? branch_id { get; set; }
        public string createdby { get; set; }
        public string messagetype { get; set; }
        public bool isdeleted { get; set; }
        public DateTime createddate { get; set; }

    }

    public class MessageDetail
    {
        public int Id { get; set; }
        public int  messageid { get; set; }
        public int branchid { get; set; }
        public int employeeid { get; set; }
          public int statusid { get; set; }
        public string createdby { get; set; }
        public string description { get; set; }
        public bool isdeleted { get; set; }
        public DateTime createddate { get; set; }

    }



    public class MessageReplyDetail
    {
        public int Id { get; set; }
        public int messagedetailid { get; set; }
        public int branchid { get; set; }
        public int employeeid { get; set; }
        public int statusid { get; set; }
        public string createdby { get; set; }
        public string description { get; set; }
        public bool isdeleted { get; set; }
        public DateTime createddate { get; set; }

    }



    public class TestEmployee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string samaccountname { get; set; }
        public int branch_id { get; set; }
        public string code { get; set; }

    }

    public class TestBranch
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
       

    }

}
