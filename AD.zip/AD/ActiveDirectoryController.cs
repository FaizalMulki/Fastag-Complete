﻿using MySql.Data.MySqlClient;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace OrchestratorAsset.Web.Controllers
{
    public class ActiveDirectoryController : Controller
    {
        // GET: ActiveDirectory

        private string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }

        public string testAdUserDetail()
        {
            string adUserDetails;
            System.Security.Principal.WindowsIdentity username = System.Security.Principal.WindowsIdentity.GetCurrent();
            adUserDetails = username.Name.ToString();
            return adUserDetails;
        }


        public string Test2()
        {
            var foundUser = UserPrincipal.FindByIdentity(new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["ADDomain"].ToString()), System.Security.Principal.WindowsIdentity.GetCurrent().Name);
            string FinalValue = "";
            PropertyInfo[] properties = typeof(UserPrincipal).GetProperties();
            foreach (PropertyInfo property in properties)
            {
                FinalValue = FinalValue + " " + property + System.Environment.NewLine;
            }

            
            return FinalValue;


        }


        public string Test3()
        {
            PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
            UserPrincipal foundUser = UserPrincipal.FindByIdentity(ctx,
            //ConfigurationManager.AppSettings["ADDomain"].ToString()), 
            System.Security.Principal.WindowsIdentity.GetCurrent().Name);
            string FinalValue = "";
            Object obj = new Object();
            PropertyInfo[] properties = typeof(UserPrincipal).GetProperties();
            foreach (PropertyInfo property in properties)
            {
                // FinalValue = FinalValue + " "+ property + System.Environment.NewLine;
                FinalValue = FinalValue + " " + property.GetValue(foundUser) + System.Environment.NewLine;
            }
            return FinalValue;
        }


        public bool Test4(string UserName, string Password)
        {

            bool isValid = true;
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["ADDomain"].ToString()))
            {
                // validate the credentials
                isValid = pc.ValidateCredentials(UserName, Password);
            }
            return isValid;
        }


        public string Test5()
        {


            bool isValid = true;
            string FinalValue = "";
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["ADDomain"].ToString()))
            {
                // validate the credentials
                //    isValid = pc.ValidateCredentials("rpa5","novigo@1");
                PropertyInfo[] properties = typeof(UserPrincipal).GetProperties();
                foreach (PropertyInfo property in properties)
                {
                    // FinalValue = FinalValue + " "+ property + System.Environment.NewLine;
                    FinalValue = FinalValue + " " + property + System.Environment.NewLine;
                }
            }
            return FinalValue;
        }










 public string ADUserDetails()
        {
            string userDetails;
            string username = System.Security.Principal.WindowsIdentity.GetCurrent().Name.Substring(System.Security.Principal.WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\") + 1);
            var foundUser = UserPrincipal.FindByIdentity(new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["ADDomain"].ToString()), IdentityType.SamAccountName, username);


            userDetails = "Display Name: " + foundUser.DisplayName.ToString() + "<br />" +
                "Given Name: " + foundUser.GivenName.ToString() + "<br />" +
                "Name: " + foundUser.Name.ToString() + "<br />" +
                "SAM Account Name: " + foundUser.SamAccountName.ToString() + "<br />" +
                "Surname: " + foundUser.Surname.ToString() + "<br />" +
                "User Principal Name: " + foundUser.UserPrincipalName.ToString() + "<br />";


            return userDetails;
        }


        public string removeValue()
        {
            var a = "this";
            var b = a.Remove(0, 1);

            var result = b + "-" + a;
            return result;

        }


        public string getFromAD()
        {
            try
            {
                using (
                    var context = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["ADDomain"].ToString()))
                {
                   
                    using (var searcher = new PrincipalSearcher(new UserPrincipal(context)))
                    {
                        UserPrincipal userPrin = new UserPrincipal(context);
                        userPrin.Enabled = true;

                        using (MySqlConnection connection = new MySqlConnection(Connection()))
                        {
                            using (MyDBContext dbcontext = new MyDBContext(connection, false))
                            {
                                List<Branch> adBranchList = new List<Branch>();
                                List<Employee> adUserList = new List<Employee>();
                                searcher.QueryFilter = userPrin;
                                foreach (var result in searcher.FindAll())
                                {
                                    DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;                               
                                    Branch adBranch = new Branch();
                                    adBranch.Name = de.Properties["sAMAccountName"].Value.ToString();
                                    adBranch.code = de.Properties["physicalDeliveryOfficeName"].Value.ToString();
                                    var checkBranchExistInDb = dbcontext.Branch.Where(x => x.code == adBranch.code);
                                    if (checkBranchExistInDb == null)
                                    {
                                        adBranchList.Add(adBranch);

                                    }
                                    dbcontext.Branch.AddRange(adBranchList);
                                    dbcontext.SaveChanges();

                                    Employee adUser = new Employee();
                                    adUser.Name = de.Properties["cn"].Value.ToString();
                                    adUser.samaccountname = de.Properties["sAMAccountName"].Value.ToString();
                                    var samAccount = adUser.samaccountname;
                                    adUser.code = samAccount.Remove(0, 1);

                                    var getBranchId = dbcontext.Branch.Where(x => x.code == adBranch.code).FirstOrDefault();
                                    if (getBranchId != null)
                                    {
                                        adUser.branch_id = getBranchId.Id;
                                    }
                                    var checkUserExistInDb = dbcontext.Employee.Where(x => x.code == adUser.code);
                                    if (checkBranchExistInDb == null)
                                    {
                                        adUserList.Add(adUser);

                                    }
                                    else
                                    {
                                        var getBranch= dbcontext.Branch.Where(x => x.code == adBranch.code).FirstOrDefault();
                                        if (getBranch != null)
                                        {
                                            var anyChanges = dbcontext.Employee.Where(x => x.code == adUser.code && x.branch_id==getBranch.Id ).FirstOrDefault();
                                            if(anyChanges==null)
                                            {
                                                dbcontext.Employee.Where(x => x.code == adUser.code).FirstOrDefault().branch_id = anyChanges.branch_id;
                                                dbcontext.SaveChanges();
                                            }
                                        }
                                    }

                                 


                                }
                                                                     
                                dbcontext.Employee.AddRange(adUserList);
                                dbcontext.SaveChanges();




                            }
                        }
                    }
                }
                return "success";
            }
            catch(Exception e)
            {
                var k = e.Message;
                return k;
            }
        }


    }




  

}


